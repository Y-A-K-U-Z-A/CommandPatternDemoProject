package commands;

import java.io.*;

public class Document {
    private static final String[] tokens = new String[4000];
    private int length;


    public Document() throws IOException {
        File file = new File("C:\\Users\\User\\Desktop\\Java OOP\\11. Test Driven Development\\FactoringDesignPatternDemo\\src\\commands\\loremipsum.txt");
        BufferedReader bf = new BufferedReader(new FileReader(file));
        String[] tokens = new String[3500];
        for (int i = 0; i < 11; i++) {
            String[] line = bf.readLine().split("\\s+");
            writingWords(line, tokens);
        }
    }

    public void open(){
        System.out.println("The document loremipsum.txt is long " + length + " words.\nThe document has been open successful.");
    }

    public void save(){
        System.out.println("The document loremipsum.txt has been successfully saved.");
    }

    private void writingWords(String[] line, String[] tokens) {
        for (int i = 0; i < line.length; i++) {
            tokens[i] = line[i];
        }
        this.length+=line.length;
    }

}
