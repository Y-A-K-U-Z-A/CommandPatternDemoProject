package commands;

public interface ActionListenerCommand {
    void execute();
}
