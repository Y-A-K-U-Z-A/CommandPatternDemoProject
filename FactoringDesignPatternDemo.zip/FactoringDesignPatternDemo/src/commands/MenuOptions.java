package commands;

public class MenuOptions {
    private ActionOpen actionOpen;
    private ActionSave actionSave;

    public MenuOptions(ActionOpen actionOpen, ActionSave actionSave) {
        this.actionOpen = actionOpen;
        this.actionSave = actionSave;
    }

    public void clickOpen(){
        this.actionOpen.execute();
    }
    public void clickSave(){
        this.actionSave.execute();
    }
}
