import commands.ActionOpen;
import commands.ActionSave;
import commands.Document;
import commands.MenuOptions;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Document doc = new Document();
        MenuOptions menu = new MenuOptions(new ActionOpen(doc), new ActionSave(doc));
        menu.clickOpen();
        menu.clickSave();
    }
}
